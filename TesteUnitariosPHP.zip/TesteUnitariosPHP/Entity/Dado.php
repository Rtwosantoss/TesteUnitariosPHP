<?php

class Dado{

    private int $lados;
    private array $historico = [];

    public function __construct( int $lados, array $historico = []) {
        $this->lados = $lados;
        $this->historico = $historico;

    }

    public function jogar(): int {

        $resultado = rand(1, $this->lados);
        $this->historico[] = [
            'valor' => $resultado,
            'data' => date('Y-m-d H:i:s')
        ];
        return $resultado;
    }

    public function adicionarHistorico($valor): void{
        $this->historico[] = [
            'valor'=> $valor,
            'data' => date('Y-m-d H:i:s')
        ];
    }

    public function getHistorico(): array{
        return $this->historico;
    }

}